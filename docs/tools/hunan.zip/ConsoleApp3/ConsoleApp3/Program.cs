﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IPEndPoint ipep = new IPEndPoint(IPAddress.Any, 7000);
            UdpClient newsock = new UdpClient(ipep);
            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
            while (true)
            {
                var bytes = newsock.Receive(ref sender);
                string data = Encoding.ASCII.GetString(bytes).Trim();
                Console.WriteLine($"{sender.Port} {sender.Address} {data}");

                if (data.StartsWith("move"))
                {
                    var t = data.Substring(4);
                    var sendbytes = Encoding.ASCII.GetBytes($"PPP 1 {t} ok");
                    newsock.Send(sendbytes, sendbytes.Length, sender);
                }
                else if (data.StartsWith("getstate"))
                {
                    var sendbytes = Encoding.ASCII.GetBytes($"moving");
                    newsock.Send(sendbytes, sendbytes.Length, sender);
                }
                else if(data.StartsWith("home"))
                {
                    var sendbytes = Encoding.ASCII.GetBytes("PPP 1 0 ok");
                    newsock.Send(sendbytes, sendbytes.Length, sender);
                }
            }
        }
    }
}
